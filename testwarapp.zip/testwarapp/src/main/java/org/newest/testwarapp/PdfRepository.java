package org.newest.testwarapp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PdfRepository extends JpaRepository<Pdfs, Long> {

}
