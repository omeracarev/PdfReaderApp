package org.newest.testwarapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestwarappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestwarappApplication.class, args);
	}

}
