package org.newest.testwarapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestwarappApplicationTests {

	@Test
	void contextLoads() {
	}

}
